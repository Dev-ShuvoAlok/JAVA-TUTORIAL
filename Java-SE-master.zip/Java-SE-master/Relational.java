
package relational;

public class Relational 
{
    public static void main(String[] args) 
    {
        int a=5,b=15,c=4;
        
        if(a>b && a>c)
        {
            System.out.println(a);
        }
        else if(b>c)
        {
            System.out.println(b);
        }
        else
        {
            System.out.println(c);
        }
        
    }   
}
