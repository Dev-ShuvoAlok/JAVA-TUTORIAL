package variables;

public class Variables {

    public static void main(String[] args) {
        
        byte b=5;
        short s=300;
        int i=100;
        float f=25.3f;
        char c='A';
        
        System.out.println(b);
        System.out.println(s);
        System.out.println(i);
        System.out.println(f);
        System.out.println(c);
    }
    
}
